package scala_examples

object for_loop {
def main(args:Array[String]){

    //var x:Int=0
///one type of for loop
  for (x<-0 to 10)

  {
    println(s"for loop :$x")
  }

  ///for each loop

  for(x<-0 until 5)
    {
      println(f"for loop until :$x%d")

    }
// multiple for loop x and y

  for(x<-0 until 5;y<-0 until 5)
  {
    println(f"for loop until x :$x%d;for loop until y:$y%d")

  }

  //list iterate in for loop

val numlist=List(1,2,3,4,5,6,7,8,9)
  val i:Int=0
  for (i<-numlist)
    {
      println(s"numlist for loop:$i")
    }

  val numArray=Array(1,2,3,4,5,6,7,8)
  val j:Int=0
  for (j<-numArray)
  {
    println(s"Array for loop:$j")
  }
///yield

  var c :Int= 0;
  val numList1 = List(1,2,3,4,5,6,7,8,9,10);

  // for loop execution with a yield
  var retVal = for{ c <- numList1 if c != 3; if c < 8 }yield c /// this for loop is used as expression

  // Now print returned values using another loop.
  for( c <- retVal){
    println( "Value of c: " + c );
  }

  //**************************imp ******************for each  loop*******************************

  val lis=List(1,2,3,4,5,6)
  lis.foreach(i=>println("for each loop: "+i))

  }

}
