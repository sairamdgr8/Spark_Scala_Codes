package scala_examples

object Functions_in_scala {
//object inside object

  //******************** objects of  Math
  object Math{
    def ma(x:Int,y:Int): Double ={
      return(scala.math.pow(x:Int,y:Int))
    }
    def square(x:Int): Double ={
      return (x*x)
    }

    def de(x:Int=45,y:Int=15): Double ={
      return (x+y)
    }
    def +(x:Int,y:Int):Int= {
      return(x+y)
    }

  }
//******************** objects of  Functions_in_scala
  def fun(x:String,y:Int):Unit={
   (x+y) // with return type unit
  }
  def samp(x:String,y:Int){
    (x+y) // without return type and return keyword
  }

  def sub(x:Int,y:Int):Int= {
    (x - y) //without return keyword and having Int as return ype
  }

  def add(x:Int,y:Int)= (x+y) //direct usage

  //def dob(x:Double,y:Double)= (x+y) //direct usage

  //*************Higher order functions object
 // *************Functions which are used as arguements to another functions
  object Higher_order_functions{
// dob is a anonymus function
    //type1
   def myhigh(x:Double,y:Double,dob:(Double,Double)=>Double):Double=dob(x,y)
   // type 2 where if we want another argument to be used then passing result of one argument function is added with anther function
  // in this im adding another argument z
    def myhigh2(x:Double,y:Double,z:Double,dob:(Double,Double)=>Double):Double=dob(dob(x,y),z)
  }


  // ***************real world implementation of partial applications**************
  // suppose if we want store the logs of a function
  import java.util.Date
    def log(date:Date,message:String): Unit ={
    println("logging the date: "+date+"  "+message)
    }


  def main(args: Array[String]) {

    //anonoymus functions
    var addition=(x:Int,y:Int)=>x+y
    println("anonoymus functions defintion  :"+addition(900,200))
    // for a class instance is required for calling inside a object
    // but  for object calling the method of object doesnt require any instance

    println("calling the method of object inside the object "+Math.ma(2,5))
    println("calling the  method of object inside the object square "+Math.square(10) )

    // calling the default parameters
    println("calling the default parameters  Math.de() "+Math.de())

    // overridding the method math.de method

    println("overridding the method math.de method:     "+Math.de(60))

    /// using operator as a function

    println(" using operator as a function "+Math.+(500,100))
    println(fun("sai",25));
    println(sub(30,25));
    println(add(30,25));
    println(samp("sai",56))

    ////**********higher order functions setup

    val res=Higher_order_functions.myhigh(1800,1800,(x,y)=>x+y)
    println("with two arguments ***type1**higher order functions : "+res)

    val res1=Higher_order_functions.myhigh2(1800,1800,1800,(x,y)=>x+y)
    println("with three arguments  ***type2**higher order functions : "+res1)

    val res2=Higher_order_functions.myhigh2(1800,1800,1800,_+_)
    println("with three arguments and wildcardsetup using '_' ***type2**higher order functions : "+res2)

   // partially applied functions
    println("*************Partially applied functions usage*************")
    val g=(x:Int,y:Int,z:Int)=>x+y+z
    // implementing z variable with wild card
    val h=g(10,20,_:Int)
    println("partial applied functions:"+h(30))

    // ***************real world implementation of partial applications**************
    // suppose if we want store the logs of a function
    // creating a instance for the  Java util date class
     val date=new Date()
    // creating anoyumus function
val newLog=log(date,_:String)
newLog("the new message 1")







  }

}
