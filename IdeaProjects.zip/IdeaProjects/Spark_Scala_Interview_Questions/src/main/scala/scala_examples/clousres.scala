package scala_examples

class clousres {
// clousre is function which uses one or more variables declared outside the function
  //1.pure clousres : where avriables declared with val
  //2.impure clousres : where avriables declared with var


 // var number = 20 //impure clousre --this need to commented for pure clousre

  val number=500// pure clousres
  val add = (x: Int) => x + number  // anayomus function

 // number=100  this need to commented for pure clousre

}
  object  clousres
{
  def main(args: Array[String]): Unit = {

    var n=new clousres
    // overridding number inside anaymous function
    var number = 200
    println(n.add(10))


}}