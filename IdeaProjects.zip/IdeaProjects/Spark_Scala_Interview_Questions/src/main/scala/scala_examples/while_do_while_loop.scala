package scala_examples

object while_do_while_loop {
  def main(args:Array[String])= {
//  while loop executed
    var x:Int=0
    while(x<10){
      println("x: "+x)
      x+=1
    }
   /// in do while loop it will execute atleast once even the condition is false
    // in do while loop  first do loop executed then while loop is done
     var y:Int=0
      do {
        println("y: "+y)
        y+=1
      }
      while(y<10)

    /// in do while loop it will execute atleast once even the condition is false
    var z:Int=1
    do {
      println("z: "+z)
      z+=1
    }
    while(z<0)



    }


}
