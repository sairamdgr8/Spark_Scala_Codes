package scala_examples

object if_else {
  def main(args:Array[String])={

  val x:Int=20
    var res="";

    // two ways of printing if else  for x

    if(x==20)
      {
        res="x==20"
      }
    else
    {
      res="x!=20"
    }
 println(res)

    // here res2 variable  need not to be intialized and need not to be assigned again hence reducing the cost performance
var res2=if(x==20)"x==20" else "x!=20"

println(res2)
    //another way printing the if and else condition without using if condition
    println(if(x==20)"x==20" else "x!=20")

  }
}
