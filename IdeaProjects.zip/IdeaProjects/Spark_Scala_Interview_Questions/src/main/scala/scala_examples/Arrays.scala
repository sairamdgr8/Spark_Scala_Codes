package scala_examples
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object Arrays {

  val x:Array[Int]=new Array[Int](3)
  val y=new Array[Int](3)
  // another way of intialization
  val i= Array(1,2,3,4,5,6,7,8,9,10)
  def main(args: Array[String]) = {
    x(0)=13
    x(1)=14
    x(2)=21

    for (z:Int<-x) {
      println(z)
    }

      // another way of describing
      for (z: Int <- 0 to (x.length - 1)) {
        println(z)
      }
        // concatination of  x array, y array not working

 var res=concat(i,x)

  }}

