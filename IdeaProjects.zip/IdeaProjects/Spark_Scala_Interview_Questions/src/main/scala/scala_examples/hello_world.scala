package scala_examples

object hello_world {

  def main(args:Array[String])={

    println("Hello World")
    println("enter any number from user input:")
    var number = scala. io. StdIn. readInt()
    println("enter any number from user input:")
    var str = scala. io. StdIn. readLine()
    println(number)
    println(str)

  }


}
