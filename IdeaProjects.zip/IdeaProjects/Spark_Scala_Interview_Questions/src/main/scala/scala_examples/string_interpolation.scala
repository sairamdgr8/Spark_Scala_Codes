package scala_examples

object string_interpolation {


    def main(args:Array[String])={

      println("Hello World")
      val name:String="Sai"
      //val age=18
      val age=18.5

      /// types of string interpolation
      println(name+" "+age+" "+" old")
      println(s"$name $age  old")
      // if suppose i change age 18 to 18.5 the last println wont work because of string interpolation with datatype so here int datatype changed to float and %d changed to %f
      //println(f"$name%s $age%d old")
      println(f"$name%s $age%f old")
      println(s"hello\nworld")
      //raw method is used to print as it is written in the string
      println(raw"hello \n world")

    }

}
