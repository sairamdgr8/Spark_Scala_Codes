package scala_examples

object match_expressions {
  def main(args: Array[String]): Unit = {
    val age=20;
    age match{
      case 20=>println("age is ",age);
      case 10=>println(age);
      case 30=>println(age);
      case 50=>println(age);
      case 60=>println(age);
      case 70=>println(age);
        // if all cases failing then default case will print
      case _=>println("default printing")
    }
    val result=age;
    age match{
      case 20=>(age);
      case 10=>(age);
      case 30=>(age);
      case 50=>(age);
      case 60=>(age);
      case 70=>(age);
      // if all cases failing then default case will print
      case _=>("default printing")
    }

    println("result =",result)

    val i:Int =5
    i match{
      case 1|3|5|7|9=>println(i+":odd number")
      case 2|4|6|8|10=>println(i+":even number")
    }

  }
}
