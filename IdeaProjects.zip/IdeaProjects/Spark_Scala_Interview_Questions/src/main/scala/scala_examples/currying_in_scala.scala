package scala_examples

object currying_in_scala {
// currying is  a technique of transforming a function
  // that takes multiple arguments into a function
  // also takes a single aruments also

 /*1*/ def add(x:Int,y:Int)=x+y
  /*2*/  def add2(x:Int)=(y:Int)=>x+y
  /*3*/ def add3(x:Int)(y:Int)=x+y
  def main(args: Array[String]): Unit = {
    //type1
    println("add: "+add(10,20))

    //type2 adding into variable and calling the second argument
    val sum=add2(200)
    println("sum:   "+sum(200))

    //type3 adding into variable and calling the second argument
    val sum1=add3(200)_
    println("sum1:   "+sum1(400))
  }
}
