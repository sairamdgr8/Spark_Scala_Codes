package scala_examples

object scala_strings {

  val num:Int=1
  val num2:Int=2
val str:String="hello this is "
  val str2:String="Sai here"

  def main(args: Array[String]): Unit = {

    println(str.concat(str2))

    println("%d--------%f---------%s---:"+num,num2,str.concat(str2))

    println("(%d--------%f---------%s---:)".format(num,num2,str.concat(str2)))




  }

}
