package com.sai.Scala_OOPS

class FirstClass {

  def FirstMethod():Unit={

    println("this is my first class hello world for FirstMethod")

  }
}
object MyFirstClass{

  def main(args:Array[String]):Unit={
// create a new object for the FirstClass class
    val m=new FirstClass()
      // calling the FirstClass class function
    m.FirstMethod()

  }

}