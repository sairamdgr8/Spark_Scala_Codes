package com.sai.examples.collectionDataFrames

import com.sai.examples.collectionRdds.SparkSession_SparkContext
import org.apache.spark.sql.SparkSession

object Accumulators   {

  def main(args: Array[String]): Unit = {


val spark_session=SparkSession.builder().appName("basic").master("local").getOrCreate()

    val rdd=spark_session.sparkContext.parallelize(Seq("this is the example", "of the error count"," checkinh how many",
    "did the error","became in the list","to count the errores count"
    ))

    val errorcount=spark_session.sparkContext.longAccumulator("error")

    rdd.foreach(x=> if(x.contains("error")){errorcount.add{1L}})

    println(errorcount)





  }

}
