package com.sai.seesion_pack

import org.apache.spark.sql.SparkSession

trait spark_session {


    lazy val spark = SparkSession
  .builder() .master("local[*]")
      .appName("spark_session")
      .getOrCreate()


}
