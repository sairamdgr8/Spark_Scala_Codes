package com.sai.examples.collectionDataFrames
import  com.sai.examples.collectionRdds.SparkSession_SparkContext
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.{lit, broadcast}
import org.apache.spark.sql.execution.joins.SortMergeJoinExec



object Broadcast_join extends App with  SparkSession_SparkContext{

  //Types of joins
// sufflehash join --->joining of tables happen on hash key
//sortmerge join  ---> joining of these tables happen on sorting the tables first and join ---by default sort merge join is the default one in sprk 2x
// broadcast join these are generally used when joining of small table with big table---broadcast join is aslo called as method join or replicated join or map only join
 //bucketed join (sufflehash join+sortmerge join)

//-----------to implement broadcast joins introduce two datasets which is having one small and one big data sets

  val df1=spark_session.range(1000).as("a") // this is one udf
  val df2=spark_session.range(1000).as("b") // this is one udf
  val df3=spark_session.range(1000).as("c") // this is one udf
  val df4=spark_session.range(1000).as("d") // this is one udf

  //df1.show()

val join1=df1.join(df2, col("a.id") === col("b.id"), "inner")
  //join1.show()
 // join1.explain()

  val join2=df1.join(broadcast(df3), col("a.id") === col("c.id"))
 // join2.show()
 // join2.explain()

    //here the table size is >10mb so it gets to be by default broadcast if greater than 10 mb than use sortmerge join

  //here the table size is >10mb so it gets to be by default broadcast if greater than 10 mb than use sortmerge join
  /// the below command is used to remove broadcast join and use the sort merge join
  spark_session.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

  val join3=df1.join((df4), col("a.id") === col("d.id"))
   join3.show()
   join3.explain()

}
