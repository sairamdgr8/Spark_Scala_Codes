package com.sai.Scala_OOPS

class args_class (val name:String,val age:Int)
  {
// this class is also called as primary constructor
  //these variables are immutable and public by default

  def my_method() {
    println("his name is " + name + " args of the class and his age is " + age)
  }

// creating auxilary constructor which is similar to constructor in java
    // where constructor is same as class name and method name same in java

    def this(name:String)
    {
      this("sai",1000)
    }

/// another method of constructor

def args_class(name:String){

println("this is type of a auxilary constructor.but not actual constructor......."+name+age)
}}

    class private_args_class (private val name1:String,private val age1:Int)  {
      //these variables are immutable and public by default

      def my_method1(){
        println("his name is "+name1+ " args of the class and his age is " + age1)
      }
    }

object MyFirstClassArgs{

  def main(args:Array[String]):Unit={
    // create a new object for the FirstClass class
    val m=new args_class("sai",25)
    // calling the FirstClass class function
    m.my_method()
    //calling auxillary method which is called as constructor in java
   m.args_class("  axuillary name sai  ")
  /// real auxillary constructor
    println()
    println("**********printing auxillary constructor**************")

    val m2=new args_class("sai")
      m2.my_method()
    val private_m=new private_args_class("private_bunny",30)
    private_m.my_method1()

    //checking the variables of class accessbile outside the class or not
    println("*************checking the variables of class accessbile outside the class or not******")
    print(m.name+" ........ printing the variables outside the class these will print as these are public by default ....  "+m.age)

    println()
    // now creating another class with private argumnets and check wheter they are accessabile outside the classs or not
   // println("*************checking the variables of class accessbile outside the class or not******")
    //print(private_m.name1+" ........ printing the variables outside the class these wont print as these are defined private  ....  "+private_m.age1)


    //println("Error:(38, 21) value name1 in class private_args_class cannot be accessed in com.sai.Scala_OOPS.private_args_class\n    print(private_m.name1+\" ........ printing the variables outside the class these wont print as these are defined private  ....  \"+private_m.age1)")

  }

}