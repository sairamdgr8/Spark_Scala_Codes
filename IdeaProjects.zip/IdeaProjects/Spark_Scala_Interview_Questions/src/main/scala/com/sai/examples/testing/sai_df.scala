package com.sai.examples.testing

import org.apache.spark.sql.SparkSession

class sai_df {

  val session=SparkSession.builder().appName("bunny").master("local")
    .getOrCreate()
  val columns = Seq("dept","emp_id","sal")
  val data = Seq(("tech",1, 2000),
    ("tech",2, 2000),
    ("sales",3, 3000),
    ("hr",4, 3900),
    ("tech",5, 5000),
    ("tech",6, 6500),
    ("tech",7, 6300),
    ("tech",8, 4900),
    ("tech",9, 3300))

  var dfFromData2 = session.createDataFrame(data).toDF(columns:_*)

  dfFromData2.show()


}
