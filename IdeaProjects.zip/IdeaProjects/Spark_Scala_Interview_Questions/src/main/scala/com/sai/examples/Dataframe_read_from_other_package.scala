package com.sai.examples
import com.sai.seesion_pack.spark_session

object Dataframe_read_from_other_package extends App with spark_session{
  val df= spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("C:\\Users\\SAI\\PycharmProjects\\pyspark-project\\pandas_sales.csv")

  import org.apache.spark.sql.types.DataTypes._

  val sch=df.schema.toList

  val jsch=df.schema.prettyJson
  print(jsch)
 

  print("""""""""""""""""""""""""""""""""""""""""",jsch.indexOf(1))
val sch1=sch.length

  print("********************************************************",sch1)
    for (i<- 0 to  sch1-1){

    print(sch(i))
  }
  df.show()


}