package com.sai.examples.testing.testing2

class sia_test {

 var x:Int=20
  var y:Int=50
//  def add(x:Int,y:Int):Int=
//  {
//  return x+y
//  }

}
