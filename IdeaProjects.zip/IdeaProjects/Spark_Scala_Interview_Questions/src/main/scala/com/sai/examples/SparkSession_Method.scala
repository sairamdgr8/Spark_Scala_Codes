package com.sai.examples

import org.apache.spark.sql.SparkSession

  trait SparkSession_Method  {

    lazy val spark=SparkSession.builder().appName("sai_method").master("local[*]").getOrCreate()

}
