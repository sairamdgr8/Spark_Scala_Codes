package com.sai.seesion_pack


  object csv_read_1 extends App with spark_session{
    val df= spark.read.format("csv")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("C:\\Users\\SAI\\PycharmProjects\\pyspark-project\\pandas_sales.csv")

    df.printSchema()
    df.show()


}
