package com.sai.examples.testing

import com.sai.examples.Dataframe_read_from_other_package
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.sai.examples.testing.sai_df
object sai_dataframe {

  val session = SparkSession.builder().appName("bunny").master("local")
    .getOrCreate()

  def mydf(mydataFrame: DataFrame): DataFrame  = {

   val vardf=mydataFrame.createOrReplaceTempView("Emp")

    //
   return( mydataFrame)

  }

  def main(args: Array[String]): Unit =
  {

 var ddf=new sai_df
var  ddf_new=ddf.dfFromData2

    ddf_new

println("*****************printing the test df******************")

    var ddf3=mydf(ddf.dfFromData2)
    println(ddf3)

  }
}
