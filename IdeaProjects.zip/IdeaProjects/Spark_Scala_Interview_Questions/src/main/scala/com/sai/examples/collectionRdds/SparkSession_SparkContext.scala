package com.sai.examples.collectionRdds
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SparkSession
trait SparkSession_SparkContext {

  lazy val spark_session = SparkSession
    .builder() .master("local[*]")
    .appName("spark_session")
    .getOrCreate()
//as per sparksession is a wrapper class so inside the spark session we have spark context no need to create another variable.
  val conf = new SparkConf()
    .setAppName("WordCount")
  //create spark context object
 lazy val spark_context = new SparkContext(conf)

}
