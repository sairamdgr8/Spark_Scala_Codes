package com.sai.Scala_OOPS

object static_object_explaination { /// this is static class where it doesn't require any instance to call its objects

  def mymethod(){
  println(" method from static class  static_object_explaination ")
  }
}
object static_object_explaination1{

  def main(args:Array[String]){

    /// simple  calling the class and its method without any instance
  ////*************these are called singletons in scala********
    static_object_explaination.mymethod()


  }
}