package com.sai.examples.testing.testing2

object sai_test2 {

  def add2(x:Int,y:Int): Int =
  {
    return x+y
  }

  def main(args: Array[String]): Unit = {

    val my=new sia_test

    println(add2(my.x,my.y))


  }
}
