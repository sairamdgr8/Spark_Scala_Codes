package com.sai.examples.collectionDataFrames
import com.sai.examples.collectionRdds.SparkSession_SparkContext
import org.apache.spark.SparkContext
//import org.apache.spark.implicts._
case class dataSet_typeSafety (name: String, age:Int) extends App with SparkSession_SparkContext
{
  val data=Seq(new dataSet_typeSafety("a",25)
    ,new dataSet_typeSafety("b", 30))

  print(data)

  //creating a df from rdd

  //rdd.printSchema()
}