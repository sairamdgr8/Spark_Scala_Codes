package com.sai.Scala_OOPS

class Singleton_CompanionObjects {
//******************* the rule of companion class is that object abd class should have the same name*************
// **** the goodness of companion objects is that we can call object methods in class
  // combination usage of static and non static methods
def test(): Unit = {
  Singleton_CompanionObjects.mymethod()
}
}
object Singleton_CompanionObjects{
  def mymethod() {
    println("object of  Singleton_CompanionObjects")
  }
}

object Main{
  def main(args:Array[String]): Unit ={
      val m=new Singleton_CompanionObjects()
    m.test()
  }

}


