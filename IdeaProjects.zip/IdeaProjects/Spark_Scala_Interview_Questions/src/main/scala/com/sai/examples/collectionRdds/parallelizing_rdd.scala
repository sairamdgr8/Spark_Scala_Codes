package com.sai.examples.collectionRdds


object parallelizing_rdd extends App with  SparkSession_SparkContext {
  val data=spark_session.sparkContext.parallelize(Seq(("maths",52),("english",75),("science",82), ("computer",65),("maths",85)))
  val sorted = data.sortByKey()
  val sorted1 = data.groupByKey()
  sorted.foreach(println)
  sorted1.foreach(println)

}
