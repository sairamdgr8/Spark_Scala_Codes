package com.sai.examples.collectionDataFrames

import com.sai.examples.collectionRdds.SparkSession_SparkContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

object RankvsDenseRankOBJ  {


    def main(args: Array[String]): Unit = {

      val session=SparkSession.builder().appName("bunny").master("local")
        .getOrCreate()

     // val context=SparkContext.


      //import spark.implicits._
      val columns = Seq("dept","emp_id","sal")
      val data = Seq(("tech",1, 2000),
      ("tech",2, 2000),
      ("sales",3, 3000),
      ("hr",4, 3900),
      ("tech",5, 5000),
      ("tech",6, 6500),
      ("tech",7, 6300),
      ("tech",8, 4900),
      ("tech",9, 3300))

      var dfFromData2 = session.createDataFrame(data).toDF(columns:_*)

      dfFromData2.show()


   dfFromData2.createOrReplaceTempView("Emp")

      session.sql("select * from Emp where emp_id>5").show()



 session.sql("select dept ,emp_id,sal ,rank() over (partition by dept order by sal) rank_col,dense_rank() over (partition by dept order by sal) dense_rank_col from Emp").show()


    }


    }
