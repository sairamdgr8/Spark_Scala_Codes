package com.sai.examples.collectionDataFrames

import com.sai.examples.collectionRdds.SparkSession_SparkContext
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SparkSession

object broadcast_variable {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder()
      .appName("Java Spark SQL basic example")
      .config("spark.master", "local")
      .getOrCreate();
// create a dataset
    val ep = Seq(("sai", 1), ("bunny", 2), ("ram", 3), ("siva", 4))
    //convert into rdd

    val emp = spark.sparkContext.parallelize(ep)

    print(emp)

    val dp = Map(1 -> "a", 2 -> "b", 3 -> "c", 4 -> "d")

    // broadcasting the dp variable
    val dep = spark.sparkContext.broadcast(dp)

   // val res = emp.map(x => x._1 + " " + x._2 + " "+ dep.value.get(x._2).get).collect().foreach(println)


    ///here dep variable used as broadcast variable we can remove the dep variabvle as broadcast variable by un perisiting it
///before un presiting we need to destory dep variable as abroadcast variable from all executors


    //dep.unpersist()

    //dep.destroy()

    //the code wont run after the broad cast variable got destroyed

println("***********************aftre unprersiting**********")
    val res1 = emp.map(x => x._1 + " " + x._2 + " "+ dep.value.get(x._2).get).collect().foreach(println)



  }
}