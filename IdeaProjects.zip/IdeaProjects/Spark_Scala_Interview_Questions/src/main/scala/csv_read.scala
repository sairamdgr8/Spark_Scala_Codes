import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object csv_read  extends App {
  val spark = SparkSession.builder
    .master("local[*]")
    .appName("basic1")
    .getOrCreate()

  val df= spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load("C:\\Users\\SAI\\PycharmProjects\\pyspark-project\\pandas_sales.csv")

  df.printSchema()
  df.show()

  ///monotonically increase column
  // use zipWithIndex to add the indexes and then toDF to get back to a dataframe
  // val newDataFrame = df.withColumn("id", monotonically_increasing_id())
  // newDataFrame.show()

  val dff=df.withColumn("id",row_number().over(Window.orderBy(lit(1))))
  dff.show()

  //creating temp view

  dff.createOrReplaceTempView("sales")

  val sqlDF = spark.sql("SELECT * FROM sales")
  sqlDF.show()

}
