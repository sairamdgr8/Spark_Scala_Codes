import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.sql.types.{ArrayType, DoubleType, IntegerType, StringType, StructField, StructType}
import com.databricks.spark.xml._
import org.apache.spark.sql.functions.{col,split,explode,monotonically_increasing_id,concat_ws,udf,map_keys,map_values}

object mappinf_array_datatype {
  def main(args: Array[String]): Unit = {

    println("*********Spark main method started**********")

    //spark session created

    val spark = SparkSession.builder().appName("xml to csv conversion").master("local").getOrCreate()

    /// logging the error
    spark.sparkContext.setLogLevel("Error")

    // create xml tags

    //RootTag
    val MyRootTag: String = "links"

    //RowTag
    val MyRowTag: String = "link"

    //RootTag
    val MyRootTag1: String = "nodes"

    //RowTag
    val MyRowTag1: String = "node"

    // load file

    val myFilePath = "physsim-network.xml"
    val rawDf = spark.read.option("rootTag", MyRootTag).option("rowTag", MyRowTag).xml(myFilePath)

    val myFilePath1 = "physsim-network.xml"
    val rawDf1 = spark.read.option("rootTag", MyRootTag1).option("rowTag", MyRowTag1).xml(myFilePath)


    // creating schema

    val mySchema2 = StructType(Array(
      StructField("_id", IntegerType, true),
      StructField("_from", IntegerType, true),
      StructField("_to", IntegerType, true),
      StructField("_length", DoubleType, true),
      StructField("_freespeed", DoubleType, true),
      StructField("_capacity", DoubleType, true),
      StructField("_permlanes", StringType, true),
      StructField("_oneway", IntegerType, true),
      StructField("_modes", StringType, true)


    ))


    val mySchema3 = StructType(Array(
      StructField("_id", IntegerType, true),
      StructField("_from", IntegerType, true),
      StructField("_to", IntegerType, true),
      StructField("_length", DoubleType, true),
      StructField("_freespeed", DoubleType, true),
      StructField("_capacity", DoubleType, true),
      StructField("_permlanes", StringType, true),
      StructField("_oneway", IntegerType, true),
      StructField("_modes", StringType, true)


    ))


    rawDf.createOrReplaceTempView("saiDf2")
    rawDf.createOrReplaceTempView("saiDf")

    rawDf1.createOrReplaceTempView("saiDfnodes")
    //


    var saiDf_new = spark.sql("select attributes.attribute._VALUE,attributes.attribute._name from saiDf")

    var saiDf2_new = spark.sql("select _capacity,_freespeed,_from,_id,_length,_modes,_oneway,_permlanes,_to from saiDf2")

    var saiDfnodes1= spark.sql("select _id as nodes_id,_x as x,_y as y from saiDfnodes")

   // saiDfnodes1.show()
  //  saiDfnodes1.printSchema()

//    saiDf_new.printSchema()
//    saiDf_new.show()



    val toMap = udf((_name: Seq[String], _VALUE: Seq[String]) => {
      _name.zip(_VALUE).toMap
    })
   import spark.implicits._
    val my_new=saiDf_new.withColumn("mapcol", toMap($"_name", $"_VALUE"))

    println("**************my_new*********************")


    my_new.show(false)
    // mapping



   my_new.printSchema()

//    val sai_my_new = my_new.withColumn("mapper",
//      concat_ws(",", col("mapcol")))
//
//
//    sai_my_new.show()



    my_new.createOrReplaceTempView("exptable")



   val ss= my_new.withColumn("mapcol2",'mapcol.cast("string"))


//    val ss1 = ss.withColumn("mapcol3",
//      concat_ws(",", col("mapcol2")))



    println("*************************printing the ss***************** ")


    ss.show(false)

    ss.printSchema()

    println("*************************printing the ss1111111***************** ")

    val ss1 = ss.select(
    split(col("mapcol2"),",").getItem(0).as("col11"),
      split(col("mapcol2"),",").getItem(1).as("LastName"))



    ss1.show(false)








   // exp.select(map_values("exptable").alias("values")).show()

    ///.select(map_values("mapcol").alias("values")).show()




//    //  val df1 = my_new.select(my_new("_name"),explode(my_new("mapcol")).alias("map"))
//    my_new.
//        explode("mapcol","tempSeq")((x: Map[String,String]) => x.toSeq).
//        withColumn("key1",col("tempSeq")("_1")).
//         withColumn("key2",col("tempSeq")("_2")).
//
//      // drop("tempSeq").
//         show(false)
//
//


    //val result = my_new.flatMap (line => line.split(",") )


    //    exp.createOrReplaceTempView("exp_table")
//
//    println("after exp_table temp view ")
//  val spark.sql("select *from exp_table")
//
//    my_new//So just a single part- file will be created
//      .write.mode(SaveMode.Overwrite)
//      .option("mapreduce.fileoutputcommitter.marksuccessfuljobs","false") //Avoid creating of crc files
//      .option("header","true") //Write the header
//      .csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\exp")
//



  }}


