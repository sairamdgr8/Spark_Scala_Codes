
  import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
  import org.apache.spark.sql.types.{ArrayType, DoubleType, IntegerType, StringType, StructField, StructType}
  import com.databricks.spark.xml._
  import org.apache.spark.sql.functions.{col,concat_ws,explode, monotonically_increasing_id, split, udf,translate}

  object ultimate_spinoer {
    def main(args: Array[String]): Unit = {

      println("*********Spark main method started**********")

      //spark session created

      val spark = SparkSession.builder().appName("xml to csv conversion").master("local").getOrCreate()

      /// logging the error
      spark.sparkContext.setLogLevel("Error")

      // create xml tags

      //RootTag
      val MyRootTag: String = "links"

      //RowTag
      val MyRowTag: String = "link"

      //RootTag
      val MyRootTag1: String = "nodes"

      //RowTag
      val MyRowTag1: String = "node"

      // load file

      val myFilePath = "physsim-network.xml"
      val rawDf = spark.read.option("rootTag", MyRootTag).option("rowTag", MyRowTag).xml(myFilePath)

      val myFilePath1 = "physsim-network.xml"
      val rawDf1 = spark.read.option("rootTag", MyRootTag1).option("rowTag", MyRowTag1).xml(myFilePath)


      // creating schema

      val mySchema2 = StructType(Array(
        StructField("_id", IntegerType, true),
        StructField("_from", IntegerType, true),
        StructField("_to", IntegerType, true),
        StructField("_length", DoubleType, true),
        StructField("_freespeed", DoubleType, true),
        StructField("_capacity", DoubleType, true),
        StructField("_permlanes", StringType, true),
        StructField("_oneway", IntegerType, true),
        StructField("_modes", StringType, true)


      ))


      rawDf.createOrReplaceTempView("saiDf2")
      rawDf.createOrReplaceTempView("saiDf")

      rawDf1.createOrReplaceTempView("saiDfnodes")
      //


      var saiDf_new = spark.sql("select attributes.attribute._VALUE,attributes.attribute._name from saiDf")

      var saiDf2_new = spark.sql("select _capacity,_freespeed,_from,_id,_length,_modes,_oneway,_permlanes,_to from saiDf2")

      var saiDfnodes1= spark.sql("select _id as nodes_id,_x as x,_y as y from saiDfnodes")

      saiDfnodes1.show()
      saiDfnodes1.printSchema()

      // this method is to convert array to string column type

      println("**************************saiDf_new*********************")

      saiDf_new.show()
      saiDf_new.printSchema()


      val toMap = udf((_name: Seq[String], _VALUE: Seq[String]) => {
        _name.zip(_VALUE).toMap
      })
      import spark.implicits._
      val my_new_map=saiDf_new.withColumn("mapcol", toMap($"_name", $"_VALUE"))

//      val saiexpnewDfdf2 = saiDf_new.withColumn("value",
//        concat_ws(",", col("_VALUE")))
//
//      val saiexpnewDfdf3 = saiDf_new.withColumn("name",
//        concat_ws(",", col("_name")))

      val my_new_map1= my_new_map.withColumn("mapcol2",'mapcol.cast("string"))

      println("***************my_new_map1****************")

      my_new_map1.show()
      my_new_map1.printSchema()


      println("***************my_new_map222****************")



  val my_new_map222=my_new_map1.withColumn("languagesAtSchool",
        concat_ws(",",col("mapcol2")))


     // my_new_map222.show(false)

      my_new_map222.createOrReplaceTempView("my_new_map222Temp")



      //val my_new_map234=spark.sql(" select languagesAtSchool.replace     FROM  my_new_map222Temp")


      my_new_map222.select($"languagesAtSchool",translate($"languagesAtSchool","[","").as("new_name"))

      my_new_map222.show(false)




      val final_result_Df1 = my_new_map1.select(
        split(col("mapcol2"),",").getItem(0).as("NAME"),
        split(col("mapcol2"),",").getItem(1).as("CLASS"))

      println("***************final_result_Df1****************")

      final_result_Df1.show()

//      val final_result_Df2 = final_result_Df1.select(
//        split(col("NAME1"),"[").getItem(0).as("NAME"),
//        split(col("CLASS1"),"]").getItem(1).as("CLASS"))

      val final_result_Df=final_result_Df1.select("NAME","CLASS")

      println("*****************final_result_Df*************************")

      final_result_Df.show()

      final_result_Df.printSchema()

      val final_result_Df123 = final_result_Df.select(
        split(col("NAME"),"->")alias("NAME1"),
        split(col("CLASS"),"->") alias("CLASS1"))

     // final_result_Df123.select($"NAME",flatten($"subjects")).show(false)

     val  solution = final_result_Df123.withColumn("NAME", concat_ws(":", $"NAME1"))
      val  solution1 = solution.withColumn("CLASS", concat_ws(":", $"CLASS1"))



      println("*****************final_result_Df123**************")
      final_result_Df123.show()
      final_result_Df123.printSchema()
      solution1.show()
      solution1.printSchema()

      val my_new_map4441= solution1.drop("_VALUE","_name","mapcol","mapcol2","languagesAtSchool")

      val smalltabnew1 = solution1.withColumn("myid123", monotonically_increasing_id())//.drop("_VALUE", "_name")

      println("************************smalltabnew1 tab******smalltabnew1**********")

      smalltabnew1.show(false)

      smalltabnew1.printSchema()


      val mdf2 = saiDf2_new.withColumn("myid2", monotonically_increasing_id())

      println("*************************mdf2******************")

      mdf2.show()
      mdf2.printSchema()

      mdf2.createOrReplaceTempView("latestnested1")

      var joinlatestnested1 = spark.sql("select _to as to ,_capacity as capacity,_freespeed as freespeed,_id as id,_length as length,_modes as modes,_oneway as oneway,_permlanes as permlanes ,myid2  from latestnested1")

      println("**********************joinlatestnested1************************")

      joinlatestnested1.show()


      var joined_df2 = smalltabnew1.join(joinlatestnested1, col("myid2") === col("myid123"), "outer")

      println("**********************************************************joined_df2******************************")


      joined_df2.show()

//
//      val finaldf=joined_df2.drop("myid2","myid123") // not removing ,"myid123" to add nodes df with monotonically df
//      finaldf.show()
//
//      finaldf.count()

      /// joining nodes and nested xml

      var join_nodes_links = saiDfnodes1.join(joined_df2, col("nodes_id") === col("id"), "outer")

      println("*********************join_nodes_links***************")
      join_nodes_links.show()



    }}

