
import org.apache.log4j.LogManager
import org.apache.spark.sql.SparkSession
//import org.config.para.physsimSchema
import org.apache.spark.sql.types.DecimalType

object darpan_xml extends App {
  val logger = LogManager.getLogger(this.getClass.getName)

  val spark = SparkSession
    .builder()
    .appName("try")
    .config("spark.memory.offHeap.enabled", true)
    .config("spark.memory.offHeap.size", "16g")
    .master("local")
    .getOrCreate()

  val physsimDF = spark
    .read.format("com.databricks.spark.xml")
    //.option("rootTag", "network")
    .option("rowTag", "network")
    // .option("inferSchema", "true")
    // .schema(physsimSchema.linksType)
    .load("physsim-network.xml")

  println("print after this")


  // just links

  physsimDF.selectExpr("links._capperiod as capperiod", "links._effectivecellsize as effectivecellsize", "links._effectivelanewidth as effectivelanewidth", "explode(links.link) as link")
    .selectExpr("capperiod", "effectivecellsize", "effectivelanewidth", "link._VALUE as value", "link._capacity as capicity", "link._freespeed as freespeed", "link._from as from", "link._id as id", "link._length as length", "link._modes as modes", "link._oneway as oneway", "link._permlanes as permlanes", "link._to as to", "explode(link.attributes.attribute) as attribute")
    .selectExpr("capperiod", "effectivecellsize", "effectivelanewidth", "value", "capicity", "freespeed", "from", "id", "length", "modes", "oneway", "permlanes", "to", "attribute._VALUE as Attribute_Value", "attribute._class as Attribute_Class", "attribute._name as Attribute_Name")
    .printSchema()


  val one = physsimDF.selectExpr("links._capperiod as capperiod", "links._effectivecellsize as effectivecellsize", "links._effectivelanewidth as effectivelanewidth", "explode(links.link) as link")
    .selectExpr("capperiod", "effectivecellsize", "effectivelanewidth", "link._VALUE as value", "link._capacity as capicity", "link._freespeed as freespeed", "link._from as from", "link._id as id", "link._length as length", "link._modes as modes", "link._oneway as oneway", "link._permlanes as permlanes", "link._to as to", "explode(link.attributes.attribute) as attribute")
    .selectExpr("capperiod", "effectivecellsize", "effectivelanewidth", "value", "capicity", "freespeed", "from", "id", "length", "modes", "oneway", "permlanes", "to", "attribute._VALUE as Attribute_Value", "attribute._class as Attribute_Class", "attribute._name as Attribute_Name")

  println("*********************************one**********************")
  one.show()
  println(one.count())

  // full flatten

  val two=physsimDF.selectExpr("nodes.node as node", "links._capperiod as capperiod", "links._effectivecellsize as effectivecellsize", "links._effectivelanewidth as effectivelanewidth", "explode(links.link) as link")
    .selectExpr("node", "capperiod", "effectivecellsize", "effectivelanewidth", "link._VALUE as value", "link._capacity as capicity", "link._freespeed as freespeed", "link._from as from", "link._id as id", "link._length as length", "link._modes as modes", "link._oneway as oneway", "link._permlanes as permlanes", "link._to as to", "explode(link.attributes.attribute) as attribute")
    .selectExpr("node", "capperiod", "effectivecellsize", "effectivelanewidth", "value", "capicity", "freespeed", "from", "id", "length", "modes", "oneway", "permlanes", "to", "attribute._VALUE as Attribute_Value", "attribute._class as Attribute_Class", "attribute._name as Attribute_Name")
    .selectExpr("explode(node) as node", "capperiod", "effectivecellsize", "effectivelanewidth", "value", "capicity", "freespeed", "from", "id", "length", "modes", "oneway", "permlanes", "to", "Attribute_Value", "Attribute_Class", "Attribute_Name")
    .selectExpr("node._id as Node_Id", "node._x as x", "node._y as y", "capperiod", "effectivecellsize", "effectivelanewidth", "value", "capicity", "freespeed", "from", "id", "length", "modes", "oneway", "permlanes", "to", "Attribute_Value", "Attribute_Class", "Attribute_Name")

  println("*********************************two**********************")

  two.show()
  println(two.count())

  println("*********************************my expression**********************")


}
