
import org.apache.log4j.LogManager
import org.apache.spark.rdd
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.monotonically_increasing_id
//import org.config.para.physsimSchema
import org.apache.spark.sql.types.DecimalType

object darpan_xml2 extends App {
  val logger = LogManager.getLogger(this.getClass.getName)

  val spark = SparkSession
    .builder()
    .appName("try")
    .config("spark.memory.offHeap.enabled", true)
    .config("spark.memory.offHeap.size", "16g")
    .master("local")
    .getOrCreate()

  val physsimDF = spark
    .read.format("com.databricks.spark.xml")
    //.option("rootTag", "network")
    .option("rowTag", "network")
    // .option("inferSchema", "true")
    // .schema(physsimSchema.linksType)
    .load("physsim-network.xml")

  println("print after this")


  // just links

 val a= physsimDF.selectExpr("explode(links.link) as link")
    .selectExpr("link._VALUE as value", "link._capacity as capicity", "link._freespeed as freespeed", "link._from as from", "link._id as id", "link._length as length", "link._modes as modes", "link._oneway as oneway", "link._permlanes as permlanes", "link._to as to", "explode(link.attributes.attribute) as attribute")
    .selectExpr("value", "capicity", "freespeed", "from", "id", "length", "modes", "oneway", "permlanes", "to", "attribute._VALUE as Attribute_Value", "attribute._class as Attribute_Class", "attribute._name as Attribute_Name")

  a.printSchema()

  val b=a.select("Attribute_Name","Attribute_Value")

var i=0


 // val c=b.collect().foreach(println)

//
//  for (row <- b.rdd.collect)
//  {
//    var name = row.mkString(",").split(",")(0)
//    var value = row.mkString(",").split(",")(1)
//    //println(name,value)
//  }

  //for (i<- b.rdd.)


//




  //// flatten



}
