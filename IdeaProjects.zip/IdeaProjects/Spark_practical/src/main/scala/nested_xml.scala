import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.sql.types.{ArrayType, DoubleType, IntegerType, StringType, StructField, StructType}
import com.databricks.spark.xml._
import org.apache.spark.sql.functions.{col, explode, monotonically_increasing_id,concat_ws}


object nested_xml {
def main(args: Array[String]): Unit = {

  println("*********Spark main method started**********")

  //spark session created

  val spark = SparkSession.builder().appName("xml to csv conversion").master("local").getOrCreate()

  /// logging the error
  spark.sparkContext.setLogLevel("Error")

  // create xml tags

  //RootTag
  val bookstoreRootTag: String = "links"

  //RowTag
  val bookRowTag: String = "link"

  // load file

  val myFilePath = "physsim-network.xml"
  val rawDf = spark.read.option("rootTag", bookstoreRootTag).option("rowTag", bookRowTag).xml(myFilePath)

  // creating schema

  val mySchema2 = StructType(Array(
    StructField("_id", IntegerType, true),
    StructField("_from",IntegerType,true),
    StructField("_to",IntegerType,true),
    StructField("_length",DoubleType,true),
    StructField("_freespeed",DoubleType,true),
    StructField("_capacity",DoubleType,true),
    StructField("_permlanes",StringType,true),
    StructField("_oneway",IntegerType,true),
    StructField("_modes",StringType,true)


  ))

  // reading the spark df

  val resultDf = spark.read.schema(mySchema2).option("rootTag", bookstoreRootTag).option("rowTag", bookRowTag).xml(myFilePath)
  //resultDf.show()

  rawDf.createOrReplaceTempView("saiDf2")
  rawDf.createOrReplaceTempView("saiDf")

   var saiDf_new=spark.sql("select attributes.attribute._VALUE,attributes.attribute._name from saiDf")
  saiDf_new.show()
  println(saiDf_new.count())

  var saiDf2_new=spark.sql("select _capacity,_freespeed,_from,_id,_length,_modes,_oneway,_permlanes,_to from saiDf2")
  saiDf2_new.show()
  println(saiDf2_new.count())


  var newDf:DataFrame=null
  var newDf2:DataFrame=null

  newDf=saiDf_new
  println(newDf.dtypes)

  newDf.show()

  println("************************newDf schema  small table****************")

  newDf.printSchema()


  val saiexpnewDf=newDf


//  println("************************saiexpnewDf schema  small table******this method is to convert array to string column type**********")
//// this method is to convert array to string column type
//
//    val saiexpnewDfdf2 = saiexpnewDf.withColumn("value",
//      concat_ws(",",col("_VALUE")))
//
//    val saiexpnewDfdf3 = saiexpnewDfdf2.withColumn("name",
//      concat_ws(",",col("_name")))
//
//    saiexpnewDfdf3.printSchema()
//
//    saiexpnewDfdf3.drop("_VALUE","_name").show()
//







  newDf2=saiDf2_new
  println(newDf2.dtypes)

  newDf2.show()






  var mdf1:DataFrame=null
  var mdf2:DataFrame=null

   mdf1 = newDf.withColumn("myid", monotonically_increasing_id())

   mdf2 = newDf2.withColumn("myid2", monotonically_increasing_id())

  mdf1.show()

  mdf1.dtypes

  mdf2.show()

  mdf1.printSchema()

  mdf2.printSchema()



  val df1 = mdf1.select(mdf1("myid"),explode(mdf1("_VALUE")).alias("value"),mdf1("_name"))


df1.select(df1("myid"),df1("value"),explode(df1("_name")).alias("name")).show()


  df1.printSchema()




  mdf2.createOrReplaceTempView("latestnested1")

  var joinlatestnested1=

    spark.sql("select _to as to ,_capacity as capacity,_freespeed as freespeed,_id as id,_length as length,_modes as modes,_oneway as oneway,_permlanes as permlanes ,myid2  from latestnested1")


  joinlatestnested1.show()

  //joinlatestnested1.write.csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\tab3")


  joinlatestnested1//So just a single part- file will be created
    .write.mode(SaveMode.Overwrite)
    .option("mapreduce.fileoutputcommitter.marksuccessfuljobs","false") //Avoid creating of crc files
    .option("header","true") //Write the header
    .csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\tab3")


  println("***********************joinlatestnested1******************")

  /////////////



  val df2=df1.select(df1("myid"),df1("value"),explode(df1("_name")).alias("name"))

  df2.createOrReplaceTempView("latestnested")


  df2//So just a single part- file will be created
    .write.mode(SaveMode.Overwrite)
    .option("mapreduce.fileoutputcommitter.marksuccessfuljobs","false") //Avoid creating of crc files
    .option("header","true") //Write the header
    .csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\tab2")

  var joinlatestnested=spark.sql("select * from latestnested")

  println("***********************joinlatestnested******************")

 joinlatestnested.show()


  //var joined_df = joinlatestnested1.join(joinlatestnested, col("joinlatestnested1.myid2") === col("joinlatestnested.myid"),"outer")




//    var joined_df1:DataFrame=null
//
//
//
//    println("*****************************joined_df************************")
//
//

  val tab2 = spark.read.option("header", "true").option("inferSchema", "true").csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\tab2")
  val tab3 = spark.read.option("header", "true").option("inferSchema", "true").csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\tab3")


  var joined_df = tab3.join(tab2, col("myid2") === col("myid"),"outer")

joined_df.show()



  joined_df.createGlobalTempView("myjoined_df")

//    var joined_df_new=spark.sql("select * from myjoined_df ")


}
}
