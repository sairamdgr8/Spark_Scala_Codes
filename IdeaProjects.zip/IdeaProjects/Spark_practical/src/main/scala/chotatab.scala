import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.sql.types.{ArrayType, DoubleType, IntegerType, StringType, StructField, StructType}
import com.databricks.spark.xml._
import org.apache.spark.sql.functions.{col, explode, monotonically_increasing_id,concat_ws}


object chotatab {
  def main(args: Array[String]): Unit = {

    println("*********Spark main method started**********")

    //spark session created

    val spark = SparkSession.builder().appName("xml to csv conversion").master("local").getOrCreate()

    /// logging the error
    spark.sparkContext.setLogLevel("Error")

    // create xml tags

    //RootTag
    val bookstoreRootTag: String = "links"

    //RowTag
    val bookRowTag: String = "link"

    // load file

    val myFilePath = "physsim-network.xml"
    val rawDf = spark.read.option("rootTag", bookstoreRootTag).option("rowTag", bookRowTag).xml(myFilePath)

    // creating schema

    val mySchema2 = StructType(Array(
      StructField("_id", IntegerType, true),
      StructField("_from", IntegerType, true),
      StructField("_to", IntegerType, true),
      StructField("_length", DoubleType, true),
      StructField("_freespeed", DoubleType, true),
      StructField("_capacity", DoubleType, true),
      StructField("_permlanes", StringType, true),
      StructField("_oneway", IntegerType, true),
      StructField("_modes", StringType, true)


    ))

    // reading the spark df

    val resultDf = spark.read.schema(mySchema2).option("rootTag", bookstoreRootTag).option("rowTag", bookRowTag).xml(myFilePath)
    //resultDf.show()

    rawDf.createOrReplaceTempView("saiDf2")
    rawDf.createOrReplaceTempView("saiDf")

    var saiDf_new = spark.sql("select attributes.attribute._VALUE,attributes.attribute._name from saiDf")
    saiDf_new.show()
    println(saiDf_new.count())

    var saiDf2_new = spark.sql("select _capacity,_freespeed,_from,_id,_length,_modes,_oneway,_permlanes,_to from saiDf2")
    saiDf2_new.show()
    println(saiDf2_new.count())


    var newDf: DataFrame = null
    var newDf2: DataFrame = null

    newDf = saiDf_new
    println(newDf.dtypes)

    newDf.show()

    println("************************newDf schema  small table****************")

    newDf.printSchema()


    val saiexpnewDf = newDf


    println("************************saiexpnewDf schema  small table******this method is to convert array to string column type**********")
    // this method is to convert array to string column type

    val saiexpnewDfdf2 = saiexpnewDf.withColumn("value",
      concat_ws(",", col("_VALUE")))

    val saiexpnewDfdf3 = saiexpnewDfdf2.withColumn("name",
      concat_ws(",", col("_name")))

    saiexpnewDfdf3.printSchema()

    // saiexpnewDfdf3.drop("_VALUE","_name").show()


    val smalltabnew1 = saiexpnewDfdf3.withColumn("myid123", monotonically_increasing_id()).drop("_VALUE", "_name")


    println("************************smalltabnew1 tab******smalltabnew1**********")


    newDf2 = saiDf2_new
    println(newDf2.dtypes)

    newDf2.show()


    var mdf1: DataFrame = null
    var mdf2: DataFrame = null

    mdf1 = newDf.withColumn("myid", monotonically_increasing_id())

    mdf2 = newDf2.withColumn("myid2", monotonically_increasing_id())


    println("****************mdf1****************************************")

    mdf1.show()

    mdf1.dtypes

    println("****************mdf2*************big  table myid2***************************")


    mdf2.show()

    mdf1.printSchema()

    mdf2.printSchema()


    mdf2.createOrReplaceTempView("latestnested1")

    var joinlatestnested1 =

      spark.sql("select _to as to ,_capacity as capacity,_freespeed as freespeed,_id as id,_length as length,_modes as modes,_oneway as oneway,_permlanes as permlanes ,myid2  from latestnested1")


    joinlatestnested1.show()

    println("schema of joinlatestnested1")
    joinlatestnested1.printSchema()


    println("schema of smalltabnew1")
    smalltabnew1.printSchema()

    println("**********************************************************joined_df2******************************")


    var joined_df2 = smalltabnew1.join(joinlatestnested1, col("myid2") === col("myid123"),"outer")

    println("**********************************************************joined_df2******************************")



    joined_df2.show()

    //joinlatestnested1.write.csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\tab3")


    smalltabnew1 //So just a single part- file will be created
      .write.mode(SaveMode.Overwrite)
      .option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //Avoid creating of crc files
      .option("header", "true") //Write the header
      .csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\smalltabnew1")


    println("***********************reading******************")



    ///////////


    joinlatestnested1 //So just a single part- file will be created
      .write.mode(SaveMode.Overwrite)
      .option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //Avoid creating of crc files
      .option("header", "true") //Write the header
      .csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\joinlatestnested1")


    val tab2 = spark.read.option("header", "true").option("inferSchema", "true").csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\smalltabnew1")
    val tab3 = spark.read.option("header", "true").option("inferSchema", "true").csv("C:\\Users\\SAI\\Desktop\\spark interviews\\tables\\joinlatestnested1")



    var joined_df = tab2.join(tab3, col("myid2") === col("myid123"),"outer")
    joined_df.show()

    joined_df.count()



  }

}
