import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.sql.types.{ArrayType, DoubleType, IntegerType, StringType, StructField, StructType}
import com.databricks.spark.xml._
import org.apache.spark.sql.functions.{col, explode, monotonically_increasing_id,concat_ws}


object xml_attributes {

  def main(args: Array[String]): Unit = {

    println("*********Spark main method started**********")

    //spark session created

    val spark=SparkSession.builder().appName("xml to csv conversion").master("local").getOrCreate()

    /// logging the error
    spark.sparkContext.setLogLevel("Error")

    // create xml tags

    //RootTag
    val bookstoreRootTag:String="nodes"

    //RowTag
    val  bookRowTag:String="node"

    // load file

    val myFilePath="attr1.xml"
    val rawDf=spark.read.option("rootTag",bookstoreRootTag).option("rowTag",bookRowTag).xml(myFilePath)

    // creating schema

    val mySchema=StructType(Array(StructField("_id",StringType,true),
      StructField("_x",StringType,true),
      StructField("_y",StringType,true)


    ))

    // reading the spark df

    val resultDf=spark.read.schema(mySchema).option("rootTag",bookstoreRootTag).option("rowTag",bookRowTag).xml(myFilePath)
    resultDf.show()

  }



}
